## Autoshun.org

Autoshun is the ancestral Open Source Intel sharing service, having been an
email subscription from 1999-2004 and a web download since 2004.

### Malicious Activities

The Autoshun.org list is artificially capped from 600 IPs to no more than 2000
IPs to prevent users from accidentally crushing their firewall.

#### IP Address
>
* Website
 - `https://www.autoshun.org/`
* Source
 - `https://www.autoshun.org/download/?api_key=< API KEY >&format=csv`
* Data
 - IP Address
* Format
 - CSV
* API/Token
 - `TBD`
* Status
 - Error
* Comments
 - URL Changed

##### Sample Output of IntelMQ

```javascript
{
  null
}
```