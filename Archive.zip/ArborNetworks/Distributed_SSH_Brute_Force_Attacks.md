## Arbor Networks

Arbor Networks is a software company founded in 2000. The company's products are
used to protect networks from denial-of-service attacks, botnets, computer
worms, and efforts to disable network routers.

### Distributed SSH Brute Force Attacks

Unknown

#### IP Address
>
* Website
 - `https://atlas.arbor.net/`
* Source
 - `http://atlas-public.ec2.arbor.net/public/ssh_attackers`
* Data
 - IP Address
* Format
 - XML
* API/Token
 - None
* Status
 - Error
* Comments
 - 403 Forbidden

##### Sample Output of IntelMQ

```javascript
{
  null
}
```